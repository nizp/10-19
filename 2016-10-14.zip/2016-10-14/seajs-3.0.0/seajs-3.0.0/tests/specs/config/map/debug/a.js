define('./b', [], { name: 'b' })
define('./a', [], { name: 'a' })