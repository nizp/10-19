define(function(require){
  var b = require('./b1')
  return b
})