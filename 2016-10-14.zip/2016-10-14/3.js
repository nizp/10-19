define(function(require,exports,module){
	var arr = require('./4.js').arr;
	//1000
	exports.arr = arr;
});
