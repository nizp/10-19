define(function(require,exports,module){
	var arr = [1,2,3,4];
	var b = {};
	exports.arr = arr;
	exports.obj = b;
});
