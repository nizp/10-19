define(function(require,exports,module){
	function fn1(){
		alert(10);
	}
	
	exports.b = fn1;
});
