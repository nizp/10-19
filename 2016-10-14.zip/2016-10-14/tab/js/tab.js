define(function(require,exports){
	var $ = require('jquery-1.11.1.js').jQuery;
	(function($){
	//第二步：创建一个tabs构造函数
	function tabs(box){
		//box为接收JQ对象，为了方便复用把box挂在了构造函数的属性下
		this.box = box;
		//设置默认的参数
		
		this.settings = require('./m.js').data2;
	}
	//第三步：给构造函数添加方法
	$.extend(tabs.prototype,{
		//初始化代码
		init:function(opt){
			/*
				有配置走配置，没配置走默认 
			*/
			for(var attr in opt){
				this.settings[attr] = opt[attr];
			}
			//调用这个对象下的所有的方法
			//console.log(this.settings)
			this.addBtn();
			this.addContent();
			this.events();
		},
		//第四步：生成按钮
		addBtn:function(){
			console.log(this.settings.header)
			require('./v.js').addBtn(this.settings.header,this.box)
		},
		//第五步：创建内容
		addContent:function(){
			//拿到内容数据
			var c = this.settings.conetent;
			var that = this;
			//创建div及内容
			$.each(c,function(i,e){
				var sClass = (i==0)?'show':'';
				var div = $('<div class="'+sClass+'"></div>');
				//有可能数据格式为json，要创建ul及li
				if(typeof e === 'object'){
					var ul = $('<ul>');
					for(var attr in e){
						ul.append($('<li>'+e[attr]+'</li>'));
					}
					div.append(ul);
				}else{
					//直接添加内容
					div.html(e);
				}
				//插入到大盒子中
				that.box.append(div);
			});
		},
		events:function(){
			var btns = this.box.find('input');
			var divs = this.box.find('div');
			btns.click(function(){
				$(this).addClass('active').siblings('input').removeClass('active');
				divs.eq($(this).index('input')).addClass('show').siblings('div').removeClass('show');
			});
		}
	});
	
	//创建插件 第一步
	var e = $.fn.extend({
		//编写一个tab插件  $('#box').tab();
		tab:function(options){//options为配置参数
			//传入的$(this)为JQ对象
			var t = new tabs($(this)); //this与$(this)是一个
			//调用init方法并且把配置参数传入进去
			t.init(options);
		}
	});
	
})(jQuery);
});

