define(function(require,exports,module){
	
	var v = {
		addBtn:function addBtn(header,box){
			$.each(header,function(i,e){
				//默认第一个为选中
				var sClass = (i==0)?'active':'';
				box.append($('<input type="button" value="'+e+'" class="'+sClass+'">'));
			});
		}
	}
	
	
	
	
	
	exports.addBtn = v.addBtn;
	
});
