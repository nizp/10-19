define(function(require,exports,module){
	function fn1(){
		var arr = require('./4.js').arr;
		var obj = require('./4.js').obj
		alert(arr);
		console.log(obj)
	}
	exports.b = fn1;
});
